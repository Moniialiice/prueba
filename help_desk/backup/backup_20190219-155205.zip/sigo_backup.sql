#
# TABLE STRUCTURE FOR: bitacora_sigo
#

DROP TABLE IF EXISTS `bitacora_sigo`;

CREATE TABLE `bitacora_sigo` (
  `id_bitacora` int(11) NOT NULL AUTO_INCREMENT,
  `idusuario_bit` int(11) NOT NULL,
  `registro_bit` longtext NOT NULL,
  `fecha_bit` date NOT NULL,
  `hora_bit` time NOT NULL,
  PRIMARY KEY (`id_bitacora`),
  KEY `idusuario_bit` (`idusuario_bit`),
  CONSTRAINT `bitacora_sigo_ibfk_1` FOREIGN KEY (`idusuario_bit`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=378 DEFAULT CHARSET=latin1;

INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (201, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-15', '17:54:19');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (202, 1, 'Búsqueda en bitacora abraham con fechas 15/02/2019-15/02/2019.', '2019-02-15', '17:55:47');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (203, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-15', '17:55:55');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (204, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-15', '17:58:38');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (205, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-15', '18:03:39');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (206, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-15', '18:05:24');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (207, 1, 'Inicio Sesión', '2019-02-18', '09:50:29');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (208, 1, 'Búsqueda en bitacora  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '09:50:46');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (209, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '09:50:55');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (210, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:18:46');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (211, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:23:01');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (212, 1, 'Búsqueda en bitacora  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:26:14');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (213, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:26:24');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (214, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:34:15');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (215, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:48:03');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (216, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '10:58:43');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (217, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:03:45');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (218, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:07:57');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (219, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:14:16');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (220, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:15:48');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (221, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:16:31');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (222, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:18:26');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (223, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:19:09');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (224, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:20:46');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (225, 1, 'Descarga bitácora en PDF  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:21:57');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (226, 1, 'Búsqueda en bitacora  con fechas 18/02/2019-18/02/2019.', '2019-02-18', '11:29:16');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (258, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:46:16');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (259, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:47:51');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (260, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:49:44');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (261, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:50:42');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (262, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:51:08');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (263, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '13:51:18');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (264, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:51:33');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (265, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:51:52');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (266, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '13:52:03');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (267, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '13:52:20');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (268, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '13:52:49');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (269, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '13:52:58');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (270, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:10:22');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (271, 1, 'Búsqueda en bitacora  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:10:54');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (272, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:11:02');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (273, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:11:45');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (274, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '14:13:22');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (275, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:13:34');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (276, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:20:05');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (277, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:20:36');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (278, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:22:57');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (279, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:23:23');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (280, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:25:36');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (281, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:25:57');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (282, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:26:10');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (283, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:26:35');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (284, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:26:50');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (285, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:27:13');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (286, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:27:35');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (287, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:28:23');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (288, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:29:53');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (289, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:33:11');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (290, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:36:35');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (291, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:38:05');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (292, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:40:40');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (293, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:41:01');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (294, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '14:52:54');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (296, 1, 'Inicio Sesión', '2019-02-18', '16:02:16');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (297, 1, 'Búsqueda en bitacora abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:02:35');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (298, 1, 'Búsqueda en bitacora abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:02:35');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (299, 1, 'Descarga bitácora en PDF abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:02:37');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (300, 1, 'Búsqueda en bitacora  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:02:44');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (301, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:02:46');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (302, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:11:33');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (303, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '16:11:47');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (304, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:11:52');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (305, 1, 'Descarga bitácora en PDF  con fechas -.', '2019-02-18', '16:12:07');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (306, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:12:11');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (307, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:13:22');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (308, 1, 'Descarga bitácora en PDF  con fechas 15/02/2019-15/02/2019.', '2019-02-18', '16:13:33');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (317, 4, 'Inicio Sesión', '2019-02-18', '16:30:52');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (318, 4, 'Búsqueda Oficio Recepción  con fechas 01/11/2018-28/02/2019.', '2019-02-18', '16:39:41');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (319, 4, 'Descarga reporte en Excel de la búsqueda  oficio recepción con fechas 01/11/2018-28/02/2019.', '2019-02-18', '16:39:44');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (320, 4, 'Descarga reporte en Excel de la búsqueda  oficio recepción con fechas 01/11/2018-28/02/2019.', '2019-02-18', '16:39:48');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (321, 4, 'Búsqueda Oficio Recepción  con fechas 01/11/2018-28/02/2019.', '2019-02-18', '16:44:12');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (322, 4, 'Búsqueda Oficio Recepción  con fechas 31/10/2018-18/02/2019.', '2019-02-18', '16:45:21');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (323, 4, 'Descarga reporte en Excel de la búsqueda  oficio recepción con fechas 31/10/2018-18/02/2019.', '2019-02-18', '16:45:24');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (324, 1, 'Inicio Sesión', '2019-02-18', '16:48:31');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (325, 1, 'Búsqueda usuario rodrigo.', '2019-02-18', '16:49:24');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (326, 1, 'Búsqueda usuario rarchundia.', '2019-02-18', '16:49:39');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (327, 4, 'Inicio Sesión', '2019-02-18', '17:00:23');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (328, 4, 'Búsqueda Oficio Atendido  con fechas 01/11/2018-28/02/2019.', '2019-02-18', '17:00:41');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (329, 4, 'Búsqueda Oficio Atendido  con fechas 01/11/2018-28/02/2019.', '2019-02-18', '17:00:41');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (330, 4, 'Búsqueda Oficio Atendido  con fechas 01/10/2018-28/02/2019.', '2019-02-18', '17:01:00');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (331, 4, 'Búsqueda Oficio Seguimiento  con fechas 03/09/2018-13/02/2019.', '2019-02-18', '17:01:18');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (332, 4, 'Consulta oficio atendido del oficio: 400LIA000/0003/2019.', '2019-02-18', '17:01:20');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (333, 4, 'Búsqueda en bitacora RODRIGO con fechas 18/02/2019-18/02/2019.', '2019-02-18', '17:03:34');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (334, 4, 'Descarga bitácora en PDF RODRIGO con fechas 18/02/2019-18/02/2019.', '2019-02-18', '17:03:38');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (335, 4, 'Búsqueda Oficio Atendido  con fechas 04/02/2019-19/02/2019.', '2019-02-18', '17:04:04');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (336, 4, 'Búsqueda Oficio Seguimiento  con fechas 04/02/2019-18/02/2019.', '2019-02-18', '17:05:18');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (337, 4, 'Consulta oficio atendido del oficio: 400LIA000/0003/2019.', '2019-02-18', '17:05:21');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (338, 4, 'Búsqueda Oficio Recepción  con fechas 01/12/2018-18/02/2019.', '2019-02-18', '17:05:32');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (339, 4, 'Consulta oficio seguimiento 400LIA000/0001/2019.', '2019-02-18', '17:05:34');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (340, 4, 'Consulta oficio seguimiento 400LIA000/0001/2019.', '2019-02-18', '17:06:41');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (341, 4, 'Consulta oficio seguimiento 400LIA000/0001/2019.', '2019-02-18', '17:08:48');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (342, 4, 'Consulta oficio seguimiento 400LIA000/0001/2019.', '2019-02-18', '17:09:51');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (343, 4, 'Descarga de Trámite en Turno del oficio seguimiento 400LIA000/0001/2019 en PDF.', '2019-02-18', '17:09:59');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (344, 4, 'Búsqueda Oficio Atendido  con fechas 01/02/2019-18/02/2019.', '2019-02-18', '17:14:42');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (345, 4, 'Búsqueda Oficio Seguimiento  con fechas 01/02/2019-18/02/2019.', '2019-02-18', '17:14:51');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (346, 4, 'Consulta oficio atendido del oficio: 400LIA000/0003/2019.', '2019-02-18', '17:14:52');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (347, 4, 'Descarga Oficio Atendido en PDF de: 400LIA000/0003/2019.', '2019-02-18', '17:15:01');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (348, 4, 'Consulta Oficio Seguimiento Captura con fechas 01/11/2018-13/02/2019.', '2019-02-18', '17:20:15');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (349, 4, 'Búsqueda en bitacora abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:54:07');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (350, 4, 'Búsqueda en bitacora abraham con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:54:15');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (351, 4, 'Búsqueda en bitacora admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:54:22');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (352, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:54:23');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (353, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:54:58');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (354, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:55:24');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (355, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:55:45');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (356, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:56:06');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (357, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:56:17');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (358, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:56:42');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (359, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:57:41');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (360, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:58:15');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (361, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:58:27');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (362, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '17:59:08');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (363, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '18:00:29');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (364, 4, 'Descarga bitácora en PDF admin con fechas 15/02/2019-15/02/2019.', '2019-02-18', '18:00:39');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (365, 4, 'Inicio Sesión', '2019-02-19', '10:31:48');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (366, 1, 'Inicio Sesión', '2019-02-19', '13:49:01');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (367, 1, 'Búsqueda Oficio Recepción  con fechas 15/02/2019-15/02/2019.', '2019-02-19', '13:49:11');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (368, 1, 'Búsqueda Oficio Recepción  con fechas 01/09/2018-15/02/2019.', '2019-02-19', '13:49:22');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (369, 4, 'Inicio Sesión', '2019-02-19', '13:49:48');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (370, 4, 'Búsqueda Oficio Seguimiento  con fechas 01/08/2018-19/02/2019.', '2019-02-19', '13:50:07');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (371, 4, 'Búsqueda en bitacora abraham con fechas 18/02/2019-18/02/2019.', '2019-02-19', '14:15:41');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (372, 4, 'Búsqueda en bitacora abraham con fechas 19/02/2019-18/02/2019.', '2019-02-19', '14:15:46');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (373, 4, 'Búsqueda en bitacora abraham con fechas 15/02/2019-18/02/2019.', '2019-02-19', '14:15:52');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (374, 4, 'Búsqueda en bitacora RODRIGO con fechas 15/02/2019-18/02/2019.', '2019-02-19', '14:16:00');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (375, 4, 'Búsqueda en bitacora RODRIGO con fechas 15/02/2019-15/02/2019.', '2019-02-19', '14:16:04');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (376, 4, 'Búsqueda en bitacora RODRIGO con fechas 18/02/2019-18/02/2019.', '2019-02-19', '14:16:16');
INSERT INTO `bitacora_sigo` (`id_bitacora`, `idusuario_bit`, `registro_bit`, `fecha_bit`, `hora_bit`) VALUES (377, 4, 'Inicio Sesión', '2019-02-19', '15:51:40');


#
# TABLE STRUCTURE FOR: captura
#

DROP TABLE IF EXISTS `captura`;

CREATE TABLE `captura` (
  `id_ofseg` int(11) NOT NULL AUTO_INCREMENT,
  `nomen_ofseg` varchar(50) NOT NULL,
  `fecha_ofseg` date NOT NULL,
  `id_etA_ofseg` int(11) NOT NULL,
  `termino_ofseg` datetime NOT NULL,
  `id_dest_ofseg` int(11) NOT NULL,
  `obs_ofseg` longtext NOT NULL,
  `aten_ofseg` int(11) NOT NULL,
  `id_ruta_ofseg` int(11) NOT NULL,
  `id_inf_ofseg` int(11) NOT NULL,
  `asunto_ofseg` longtext NOT NULL,
  `id_oficioEntrada_ofseg` int(11) NOT NULL,
  PRIMARY KEY (`id_ofseg`),
  KEY `captura` (`aten_ofseg`),
  KEY `captura_2` (`id_etA_ofseg`),
  KEY `captura_3` (`id_dest_ofseg`),
  KEY `captura_4` (`id_ruta_ofseg`),
  KEY `captura_5` (`id_inf_ofseg`),
  KEY `captura_6` (`id_oficioEntrada_ofseg`),
  CONSTRAINT `captura` FOREIGN KEY (`aten_ofseg`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `captura_2` FOREIGN KEY (`id_etA_ofseg`) REFERENCES `etiquetas_asunto` (`id_etAsunto`),
  CONSTRAINT `captura_3` FOREIGN KEY (`id_dest_ofseg`) REFERENCES `destinatario` (`id_destinatario`),
  CONSTRAINT `captura_4` FOREIGN KEY (`id_ruta_ofseg`) REFERENCES `ruta_oficio` (`id_ruta`),
  CONSTRAINT `captura_5` FOREIGN KEY (`id_inf_ofseg`) REFERENCES `informar` (`id_informar`),
  CONSTRAINT `captura_6` FOREIGN KEY (`id_oficioEntrada_ofseg`) REFERENCES `oficio_entrada` (`id_oficioEntrada`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: captura_atendido
#

DROP TABLE IF EXISTS `captura_atendido`;

CREATE TABLE `captura_atendido` (
  `id_ofAtenCap` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_atenCap` date NOT NULL,
  `nombre_atenCap` varchar(100) NOT NULL,
  `cargo_atenCap` longtext NOT NULL,
  `descCap` longtext NOT NULL,
  `arch_atenCap` varchar(100) NOT NULL,
  `copia_aCap` varchar(200) NOT NULL,
  `id_ofseg` int(11) NOT NULL,
  `atencionCap` int(11) NOT NULL,
  PRIMARY KEY (`id_ofAtenCap`),
  KEY `cap_aten1` (`id_ofseg`),
  KEY `cap_aten2` (`atencionCap`),
  CONSTRAINT `cap_aten1` FOREIGN KEY (`id_ofseg`) REFERENCES `captura` (`id_ofseg`),
  CONSTRAINT `cap_aten2` FOREIGN KEY (`atencionCap`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dependencias
#

DROP TABLE IF EXISTS `dependencias`;

CREATE TABLE `dependencias` (
  `id_dependencias` int(11) NOT NULL AUTO_INCREMENT,
  `dependencias` varchar(150) NOT NULL,
  PRIMARY KEY (`id_dependencias`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `dependencias` (`id_dependencias`, `dependencias`) VALUES (1, 'FISCALIA GENERAL DE JUSTICIA DEL ESTADO DE MÉXICO');


#
# TABLE STRUCTURE FOR: destinatario
#

DROP TABLE IF EXISTS `destinatario`;

CREATE TABLE `destinatario` (
  `id_destinatario` int(11) NOT NULL AUTO_INCREMENT,
  `conase` int(11) NOT NULL,
  `valle_toluca` int(11) NOT NULL,
  `valle_mexico` int(11) NOT NULL,
  `zona_oriente` int(11) NOT NULL,
  `fiscal_general` int(11) NOT NULL,
  `vicefiscalia` int(11) NOT NULL,
  `oficialia_mayor` int(11) NOT NULL,
  `informacion_estadistica` int(11) NOT NULL,
  `central_juridico` int(11) NOT NULL,
  `servicio_carrera` int(11) NOT NULL,
  `otra` varchar(250) NOT NULL,
  PRIMARY KEY (`id_destinatario`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;

INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (84, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (85, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (86, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (87, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (88, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (89, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (90, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (91, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (92, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (93, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (94, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (95, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (96, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (97, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (98, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (99, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (101, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (102, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (103, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (104, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (105, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (106, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (107, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (108, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (109, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (110, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (111, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (112, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (113, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (114, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (115, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (116, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (117, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (118, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (119, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (120, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (121, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (122, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (123, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (124, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (125, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (126, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (127, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, '');
INSERT INTO `destinatario` (`id_destinatario`, `conase`, `valle_toluca`, `valle_mexico`, `zona_oriente`, `fiscal_general`, `vicefiscalia`, `oficialia_mayor`, `informacion_estadistica`, `central_juridico`, `servicio_carrera`, `otra`) VALUES (128, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, '');


#
# TABLE STRUCTURE FOR: etiquetas_asunto
#

DROP TABLE IF EXISTS `etiquetas_asunto`;

CREATE TABLE `etiquetas_asunto` (
  `id_etAsunto` int(11) NOT NULL AUTO_INCREMENT,
  `colaboracion` int(11) NOT NULL,
  `amparos` int(11) NOT NULL,
  `solicitudes` int(11) NOT NULL,
  `gestion` int(11) NOT NULL,
  `cursos_capacitaciones` int(11) NOT NULL,
  `juzgados` int(11) NOT NULL,
  `recursos_humanos` int(11) NOT NULL,
  `telefonia` int(11) NOT NULL,
  `estadistica` int(11) NOT NULL,
  `relaciones_interis` int(11) NOT NULL,
  `boletas_audiencia` int(11) NOT NULL,
  `copias_conocimiento` int(11) NOT NULL,
  PRIMARY KEY (`id_etAsunto`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=latin1;

INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (84, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (85, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (86, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (87, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (88, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (89, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (90, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (91, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (92, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (93, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (94, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (95, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (96, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (97, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (98, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (99, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (100, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (101, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (102, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (103, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (104, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (105, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (106, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (107, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (108, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (109, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (110, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (111, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (112, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (113, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (114, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (115, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (116, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (117, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (118, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (119, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (120, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (121, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (122, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (123, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (124, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (125, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (126, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (127, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
INSERT INTO `etiquetas_asunto` (`id_etAsunto`, `colaboracion`, `amparos`, `solicitudes`, `gestion`, `cursos_capacitaciones`, `juzgados`, `recursos_humanos`, `telefonia`, `estadistica`, `relaciones_interis`, `boletas_audiencia`, `copias_conocimiento`) VALUES (128, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);


#
# TABLE STRUCTURE FOR: informar
#

DROP TABLE IF EXISTS `informar`;

CREATE TABLE `informar` (
  `id_informar` int(11) NOT NULL AUTO_INCREMENT,
  `esta_oficina` int(11) NOT NULL,
  `peticionario` int(11) NOT NULL,
  `institucion_requiriente` int(11) NOT NULL,
  PRIMARY KEY (`id_informar`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=latin1;

INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (119, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (120, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (121, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (122, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (123, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (124, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (125, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (126, 1, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (127, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (128, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (129, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (130, 1, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (131, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (132, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (133, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (134, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (135, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (136, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (137, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (138, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (139, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (140, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (141, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (142, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (143, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (144, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (145, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (146, 1, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (147, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (148, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (149, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (150, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (151, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (152, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (153, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (154, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (155, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (156, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (157, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (158, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (159, 0, 1, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (160, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (161, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (162, 1, 0, 0);
INSERT INTO `informar` (`id_informar`, `esta_oficina`, `peticionario`, `institucion_requiriente`) VALUES (163, 1, 0, 0);


#
# TABLE STRUCTURE FOR: oficio_atendido
#

DROP TABLE IF EXISTS `oficio_atendido`;

CREATE TABLE `oficio_atendido` (
  `id_oficioAtendido` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_atendido` date NOT NULL,
  `nombre_aten` varchar(100) NOT NULL,
  `cargo_aten` longtext NOT NULL,
  `descripcion` longtext NOT NULL,
  `arch_atendido` varchar(100) NOT NULL,
  `copia_a` varchar(200) NOT NULL,
  `id_oficioseg` int(11) NOT NULL,
  `atencion` int(11) NOT NULL,
  PRIMARY KEY (`id_oficioAtendido`),
  KEY `id_oficioseg` (`id_oficioseg`),
  KEY `oficio_atendido` (`atencion`),
  CONSTRAINT `oficio_atendido` FOREIGN KEY (`atencion`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `oficio_atendido_2` FOREIGN KEY (`id_oficioseg`) REFERENCES `oficio_seguimiento` (`id_oficioseg`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `oficio_atendido` (`id_oficioAtendido`, `fecha_atendido`, `nombre_aten`, `cargo_aten`, `descripcion`, `arch_atendido`, `copia_a`, `id_oficioseg`, `atencion`) VALUES (1, '2019-02-06', 'LIC. DILCYA SAMANTHA GARCIA ESPINOZA DE LOS MONTEROS.', 'SECRETARIO PARTICULAR', 'Curso de capacitación con la temática reglas mínimas de las naciones unidad sobre las medidas no privativas de la libertad ', '400LIA0000003201906022019.pdf', 'Rodrigo Archundia', 108, 1);
INSERT INTO `oficio_atendido` (`id_oficioAtendido`, `fecha_atendido`, `nombre_aten`, `cargo_aten`, `descripcion`, `arch_atendido`, `copia_a`, `id_oficioseg`, `atencion`) VALUES (3, '2018-09-28', 'LIC. DILCYA SAMANTHA GARCIA ESPINOZA DE LOS MONTEROS.', 'FISCAL ESPECIALIZADO DE SECUESTROS DE ZONA ORIENTE.', 'EL OFICIO ES DE CONOCIMIENTO DEL SERVICIO BRINDADO POR TAL MOTIVO SE ARCHIVA EN CARPETA DE CORRESPONDENCIA. \r\n', '400LIA00000042019280920181.pdf', '', 110, 4);
INSERT INTO `oficio_atendido` (`id_oficioAtendido`, `fecha_atendido`, `nombre_aten`, `cargo_aten`, `descripcion`, `arch_atendido`, `copia_a`, `id_oficioseg`, `atencion`) VALUES (4, '2018-09-26', 'MTRO. RAFAEL ESQUIVEL BLANCO. ', 'DIRECTOR GENERAL DE ENLACE INTERINSTITUCIONAL.\r\n', 'EL OFICIO FUE REMITIDO DIRECTAMENTE A LA FISCALIA DE SECUESTROS DE ZONA ORIENTE, POR LO QUE SE DA CONTESTACIONN DIRECTA AL JUEZ DE CONTROL EN TIEMPO Y FORMA. \r\n', '400LI001000422019-26092018.pdf', '', 112, 1);


#
# TABLE STRUCTURE FOR: oficio_entrada
#

DROP TABLE IF EXISTS `oficio_entrada`;

CREATE TABLE `oficio_entrada` (
  `id_oficioEntrada` int(11) NOT NULL AUTO_INCREMENT,
  `no_oficioEntrada` varchar(100) NOT NULL,
  `firma_origen` varchar(200) NOT NULL,
  `cargo` longtext NOT NULL,
  `peticion` varchar(250) NOT NULL,
  `arch_entrada` varchar(200) NOT NULL,
  `atencion` int(11) NOT NULL,
  `fecha_ent` datetime NOT NULL,
  `fecha_rec` datetime NOT NULL,
  `fecha_real` date NOT NULL,
  PRIMARY KEY (`id_oficioEntrada`),
  KEY `atencion` (`atencion`),
  CONSTRAINT `oficio_entrada_ibfk_1` FOREIGN KEY (`atencion`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

INSERT INTO `oficio_entrada` (`id_oficioEntrada`, `no_oficioEntrada`, `firma_origen`, `cargo`, `peticion`, `arch_entrada`, `atencion`, `fecha_ent`, `fecha_rec`, `fecha_real`) VALUES (82, 'MJ03454/2018', 'MTRA. ADRIANA CABRERA SANTANA.', 'SECRETARIA TECNICA DEL C. FISCAL GENERAL.', 'JUEZ LIC. IGNACIO GUZMAN COLIN REMITE OFICIO 10050, C. A. 1843/2014, SOLICITANDO INFORME EL NUMERO DE CARPETA DE INVESTIGACION CON QUE SE RADICO EL ESTADO QUE GUARDA Y NOMBRE DEL FISCAL ENCARGADO DE LA INVESTIGACION Y DOMICILIO DONDE SE LOCALICE.\r\n', 'MJ0345420181.pdf', 1, '2018-09-21 17:53:00', '2018-09-24 13:43:00', '2018-08-31');
INSERT INTO `oficio_entrada` (`id_oficioEntrada`, `no_oficioEntrada`, `firma_origen`, `cargo`, `peticion`, `arch_entrada`, `atencion`, `fecha_ent`, `fecha_rec`, `fecha_real`) VALUES (83, 'CIRCULAR INTERNA 15', 'MTRA. ADRIANA CABRERA SANTANA', 'SECRETARIO PARTICULAR ', 'POR EL MEDIO DE ESTE OFICIO LE PIDO CORDIALMENTE LA BÚSQUEDA DE ANTONIO MANJARREZ ', 'CIRCULAR_INTERNA_15.pdf', 1, '2018-09-25 09:27:00', '2018-09-26 11:39:00', '2018-09-26');
INSERT INTO `oficio_entrada` (`id_oficioEntrada`, `no_oficioEntrada`, `firma_origen`, `cargo`, `peticion`, `arch_entrada`, `atencion`, `fecha_ent`, `fecha_rec`, `fecha_real`) VALUES (84, '400LK2100-1395/2018', 'LIC. JULIO GUILLERMO ORTIZ BERNAL.', 'SECRETARIO PARTICULAR ', 'EN COLABORACIÓN DE LA BÚSQUEDA DE LA PERSONA VICENTE CONTRERAS', '400LK2100-13952018.pdf', 1, '2018-09-25 12:34:00', '2018-09-25 00:00:00', '2019-01-16');
INSERT INTO `oficio_entrada` (`id_oficioEntrada`, `no_oficioEntrada`, `firma_origen`, `cargo`, `peticion`, `arch_entrada`, `atencion`, `fecha_ent`, `fecha_rec`, `fecha_real`) VALUES (85, '10772/2018', 'DR. GUILLERMO E. GONZALEZ MEDINA.', 'SECRETARIO PARTICULAR', 'BÚSQUEDA DE PERSONA EN EL SAN MATEO OXTA', '107722018.pdf', 1, '2018-09-27 09:30:00', '2018-09-27 13:41:00', '2018-09-25');
INSERT INTO `oficio_entrada` (`id_oficioEntrada`, `no_oficioEntrada`, `firma_origen`, `cargo`, `peticion`, `arch_entrada`, `atencion`, `fecha_ent`, `fecha_rec`, `fecha_real`) VALUES (86, 'CIRCULAR INTERNA 657', 'LIC. JULIO GUILLERMO ORTIZ BERNAL.', 'SECRETARIO PARTICULAR', 'PRUEBA PARA LA INSERCIÓN DEL  OFICIO SEGUIMIENTO', 'CIRCULAR_INTERNA_657.pdf', 1, '2019-01-15 05:36:00', '2019-01-16 12:42:00', '2019-01-09');
INSERT INTO `oficio_entrada` (`id_oficioEntrada`, `no_oficioEntrada`, `firma_origen`, `cargo`, `peticion`, `arch_entrada`, `atencion`, `fecha_ent`, `fecha_rec`, `fecha_real`) VALUES (87, '400L11A00/2579/2018', 'MTRO. RAFAEL ESQUIVEL BLANCO. ', 'DIRECTOR GENERAL DE ENLACE INTERINSTITUCIONAL.\r\n', 'COLABORACION DE BUSQUEDA DE DIVERSAS PERSONAS EN LOS OFICIOS 45807 CAUSA PENAL 10/2012; Y UEIDFF-V-465/2018 C. I. FED/SEIDF/UNAI-MEX/0000814/2017\r\n', '400L11A0025792018.pdf', 1, '2018-09-24 13:55:00', '2018-09-14 14:54:00', '2018-09-14');


#
# TABLE STRUCTURE FOR: oficio_seguimiento
#

DROP TABLE IF EXISTS `oficio_seguimiento`;

CREATE TABLE `oficio_seguimiento` (
  `id_oficioseg` int(11) NOT NULL AUTO_INCREMENT,
  `nomenclatura` varchar(50) NOT NULL,
  `fecha` date NOT NULL,
  `id_etAsunto` int(11) NOT NULL,
  `termino` datetime NOT NULL,
  `id_destinatario` int(11) NOT NULL,
  `observaciones` longtext NOT NULL,
  `atencion` int(11) NOT NULL,
  `id_ruta` int(11) NOT NULL,
  `id_informar` int(11) NOT NULL,
  `asunto` longtext NOT NULL,
  `id_oficioEntrada` int(11) NOT NULL,
  PRIMARY KEY (`id_oficioseg`),
  KEY `oficio_seguimiento_ibfk_1` (`atencion`),
  KEY `oficio_seguimiento_ibfk_2` (`id_etAsunto`),
  KEY `oficio_seguimiento_ibfk_3` (`id_destinatario`),
  KEY `oficio_seguimiento_ibfk_4` (`id_ruta`),
  KEY `oficio_seguimiento_ibfk_5` (`id_informar`),
  KEY `oficio_seguimiento_ibfk_7` (`id_oficioEntrada`),
  CONSTRAINT `oficio_seguimiento_ibfk_1` FOREIGN KEY (`atencion`) REFERENCES `usuario` (`id_usuario`),
  CONSTRAINT `oficio_seguimiento_ibfk_2` FOREIGN KEY (`id_etAsunto`) REFERENCES `etiquetas_asunto` (`id_etAsunto`),
  CONSTRAINT `oficio_seguimiento_ibfk_3` FOREIGN KEY (`id_destinatario`) REFERENCES `destinatario` (`id_destinatario`),
  CONSTRAINT `oficio_seguimiento_ibfk_4` FOREIGN KEY (`id_ruta`) REFERENCES `ruta_oficio` (`id_ruta`),
  CONSTRAINT `oficio_seguimiento_ibfk_5` FOREIGN KEY (`id_informar`) REFERENCES `informar` (`id_informar`),
  CONSTRAINT `oficio_seguimiento_ibfk_7` FOREIGN KEY (`id_oficioEntrada`) REFERENCES `oficio_entrada` (`id_oficioEntrada`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=latin1;

INSERT INTO `oficio_seguimiento` (`id_oficioseg`, `nomenclatura`, `fecha`, `id_etAsunto`, `termino`, `id_destinatario`, `observaciones`, `atencion`, `id_ruta`, `id_informar`, `asunto`, `id_oficioEntrada`) VALUES (105, '400LIA000/0001/2019', '2019-02-04', 121, '2019-02-05 16:42:00', 121, 'SE INFORMA Y SE INVITA A PARTICIPAR EN EL CURSO DE CAPACITACION \r\n', 1, 123, 156, 'SE INFORMA Y SE INVITA A PARTICIPAR EN EL CURSO DE CAPACITACION CON LA TEMATICA REGLAS MINIMAS DE LAS NACIONES UNIDAS SOBRE LAS MEDIDAS NO PRIVATIVAS DE LA LIBERTAD \"REGLAS DE TOKIO\" Y REGLAS MINIMAS DE LAS NACIONES UNIDAS PARA EL TRATAMEINTO DE LOS RECLUSOS \"REGLAS NELSON MANDELA\"\r\n', 86);
INSERT INTO `oficio_seguimiento` (`id_oficioseg`, `nomenclatura`, `fecha`, `id_etAsunto`, `termino`, `id_destinatario`, `observaciones`, `atencion`, `id_ruta`, `id_informar`, `asunto`, `id_oficioEntrada`) VALUES (106, '400LI0010/0041/2019', '2019-02-04', 122, '2019-02-06 17:47:00', 122, 'SE INFORMA Y SE INVITA A PARTICIPAR EN EL CURSO DE CAPACITACION CON LA TEMATICA REGLAS MINIMAS DE LAS NACIONES UNIDAS SOBRE LAS MEDIDAS NO PRIVATIVAS DE LA LIBERTAD \"REGLAS DE TOKIO\" Y REGLAS MINIMAS DE LAS NACIONES UNIDAS PARA EL TRATAMEINTO DE LOS RECLUSOS \"REGLAS NELSON MANDELA\"\r\n', 1, 124, 157, 'SE INFORMA Y SE INVITA A PARTICIPAR EN EL CURSO DE CAPACITACION CON LA TEMATICA REGLAS MINIMAS DE LAS NACIONES UNIDAS SOBRE LAS MEDIDAS NO PRIVATIVAS DE LA LIBERTAD \"REGLAS DE TOKIO\" Y REGLAS MINIMAS DE LAS NACIONES UNIDAS PARA EL TRATAMEINTO DE LOS RECLUSOS \"REGLAS NELSON MANDELA\"\r\n', 82);
INSERT INTO `oficio_seguimiento` (`id_oficioseg`, `nomenclatura`, `fecha`, `id_etAsunto`, `termino`, `id_destinatario`, `observaciones`, `atencion`, `id_ruta`, `id_informar`, `asunto`, `id_oficioEntrada`) VALUES (108, '400LIA000/0003/2019', '2019-02-05', 124, '2019-02-06 14:43:00', 124, 'REGLAS MINIMAS DE LAS NACIONES UNIDAS PARA EL TRATAMEINTO DE LOS RECLUSOS\r\n', 1, 126, 159, 'SE INFORMA Y SE INVITA A PARTICIPAR EN EL CURSO DE CAPACITACION CON LA TEMATICA REGLAS MINIMAS DE LAS NACIONES UNIDAS SOBRE LAS MEDIDAS NO PRIVATIVAS DE LA LIBERTAD \"REGLAS DE TOKIO\" Y REGLAS MINIMAS DE LAS NACIONES UNIDAS PARA EL TRATAMEINTO DE LOS RECLUSOS \"REGLAS NELSON MANDELA\"\r\n', 85);
INSERT INTO `oficio_seguimiento` (`id_oficioseg`, `nomenclatura`, `fecha`, `id_etAsunto`, `termino`, `id_destinatario`, `observaciones`, `atencion`, `id_ruta`, `id_informar`, `asunto`, `id_oficioEntrada`) VALUES (110, '400LIA000/0004/2019', '2018-09-26', 126, '2018-09-28 14:43:00', 126, 'SE ESPERA RESPUESTA EN 24 HORAS', 4, 128, 161, 'EL OFICIO MJO03454/2018 FUE EMITIDO DIRECTAMENTE A LA FISCALÍA DE SECUESTROS DE ZONA ORIENTE POR LO QUE SE DA CONTESTACIÓN DIRECTA AL JUEZ DE CONTROL DE TIEMPO Y FORMA.', 84);
INSERT INTO `oficio_seguimiento` (`id_oficioseg`, `nomenclatura`, `fecha`, `id_etAsunto`, `termino`, `id_destinatario`, `observaciones`, `atencion`, `id_ruta`, `id_informar`, `asunto`, `id_oficioEntrada`) VALUES (112, '400LI0010/0042/2019', '2018-09-26', 128, '2018-09-27 13:40:00', 128, 'OFICIOS 45807 CAUSA PENAL 10/2012; Y UEIDFF-V-465/2018 C. I. FED/SEIDF/UNAI-MEX/0000814/2017\r\n', 1, 130, 163, 'EN RESPUESTA A LA COLABORACION DE BUSQUEDA DE DIVERSAS PERSONAS EN LOS OFICIOS 45807 CAUSA PENAL 10/2012; Y UEIDFF-V-465/2018 C. I. FED/SEIDF/UNAI-MEX/0000814/2017\r\n', 87);


#
# TABLE STRUCTURE FOR: ruta_oficio
#

DROP TABLE IF EXISTS `ruta_oficio`;

CREATE TABLE `ruta_oficio` (
  `id_ruta` int(11) NOT NULL AUTO_INCREMENT,
  `realiza_diligencias` int(11) NOT NULL,
  `recibir_personalmente` int(11) NOT NULL,
  `gestionar_peticion` int(11) NOT NULL,
  `archivo` int(11) NOT NULL,
  `otras` varchar(250) NOT NULL,
  PRIMARY KEY (`id_ruta`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (86, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (87, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (88, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (89, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (90, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (91, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (92, 0, 1, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (93, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (94, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (95, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (96, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (97, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (98, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (99, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (100, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (101, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (102, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (103, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (104, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (105, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (106, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (107, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (108, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (109, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (110, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (111, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (112, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (113, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (114, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (115, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (116, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (117, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (118, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (119, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (120, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (121, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (122, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (123, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (124, 0, 0, 1, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (125, 1, 0, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (126, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (127, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (128, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (129, 0, 1, 0, 0, '');
INSERT INTO `ruta_oficio` (`id_ruta`, `realiza_diligencias`, `recibir_personalmente`, `gestionar_peticion`, `archivo`, `otras`) VALUES (130, 1, 0, 0, 0, '');


#
# TABLE STRUCTURE FOR: tipousuario
#

DROP TABLE IF EXISTS `tipousuario`;

CREATE TABLE `tipousuario` (
  `id_tipoUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `tipoUsuario` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tipoUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tipousuario` (`id_tipoUsuario`, `tipoUsuario`) VALUES (1, 'ADMINISTRADOR');
INSERT INTO `tipousuario` (`id_tipoUsuario`, `tipoUsuario`) VALUES (2, 'COORDINADOR GENERAL');
INSERT INTO `tipousuario` (`id_tipoUsuario`, `tipoUsuario`) VALUES (3, 'SECRETARIADO');
INSERT INTO `tipousuario` (`id_tipoUsuario`, `tipoUsuario`) VALUES (4, 'CAPTURA');


#
# TABLE STRUCTURE FOR: usuario
#

DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellidop` varchar(50) NOT NULL,
  `apellidom` varchar(50) NOT NULL,
  `activo` int(11) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `id_tipoUsuario` int(11) NOT NULL,
  `id_dependencias` int(11) NOT NULL,
  PRIMARY KEY (`id_usuario`),
  KEY `id_tipoUsuario` (`id_tipoUsuario`),
  KEY `id_dependencias` (`id_dependencias`),
  CONSTRAINT `usuario` FOREIGN KEY (`id_dependencias`) REFERENCES `dependencias` (`id_dependencias`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_tipoUsuario`) REFERENCES `tipousuario` (`id_tipoUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellidop`, `apellidom`, `activo`, `correo`, `password`, `id_tipoUsuario`, `id_dependencias`) VALUES (1, 'ADMINISTRADOR', 'ADMIN', 'ADMIN', 1, 'mmendezg@fiscaliaedomex.gob.mx', 'c3VwZXJ1c3Vhcmlv', 1, 1);
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellidop`, `apellidom`, `activo`, `correo`, `password`, `id_tipoUsuario`, `id_dependencias`) VALUES (2, 'lprueba', 'coordinador', 'pruebacoord', 1, 'lprueba@gmail.com', 'Y29vcmRpbmFkb3I=', 2, 1);
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellidop`, `apellidom`, `activo`, `correo`, `password`, `id_tipoUsuario`, `id_dependencias`) VALUES (3, 'Secretaria', 'psecretariado', 'psecretariado', 1, 'secretariado@gmail.com', 'c2VjcmV0YXJpYWRv', 3, 1);
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellidop`, `apellidom`, `activo`, `correo`, `password`, `id_tipoUsuario`, `id_dependencias`) VALUES (4, 'RODRIGO', 'ARCHUNDIA', 'BARRIENTOS', 1, 'rarchundia@fiscaliaedomex.gob.mx', 'cmFyY2h1bmRpYQ==', 1, 1);
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellidop`, `apellidom`, `activo`, `correo`, `password`, `id_tipoUsuario`, `id_dependencias`) VALUES (6, 'ABRAHAM', 'ESTEBAN', 'ACOSTA', 1, 'aestebana@fiscaliaedomex.gob.mx', 'YWVzdGViYW5h', 2, 1);
INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellidop`, `apellidom`, `activo`, `correo`, `password`, `id_tipoUsuario`, `id_dependencias`) VALUES (7, 'PCaptura', 'P', 'Captura', 1, 'captura@fiscaliaedomex.gob.mx', 'Y2FwdHVyYTE=', 4, 1);


